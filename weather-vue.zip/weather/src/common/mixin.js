import BMap from 'BMap'
import { mapState } from 'vuex'
import { baseData, GetHome } from 'network/home'

export const AmapMixin = {
  data () {
    return {
      AmapL: [],
      GetHome: { wind: [] },
      homeData: {},
      address: {}
    }
  },
  methods: {
    /**
     * 获取定位信息
    */
    getLocation () {
      const _this = this
      const geolocation = new BMap.Geolocation()
      // BMAP_STATUS_SUCCESS检索成功。对应数值“0”。
      // BMAP_STATUS_CITY_LIST城市列表。对应数值“1”。
      // BMAP_STATUS_UNKNOWN_LOCATION位置结果未知。对应数值“2”。
      // BMAP_STATUS_UNKNOWN_ROUTE导航结果未知。对应数值“3”。
      // BMAP_STATUS_INVALID_KEY非法密钥。对应数值“4”。
      // BMAP_STATUS_INVALID_REQUEST非法请求。对应数值“5”。
      // BMAP_STATUS_PERMISSION_DENIED没有权限。对应数值“6”。(自 1.1 新增)
      // BMAP_STATUS_SERVICE_UNAVAILABLE服务不可用。对应数值“7”。(自 1.1 新增)
      // BMAP_STATUS_TIMEOUT超时。对应数值“8”。(自 1.1 新增)
      geolocation.getCurrentPosition(data => {
        if (geolocation.getStatus() === 0) {
          _this.AmapL = [data.point.lng, data.point.lat]
          _this.address = data.address
          _this.getInit()
        }
      }, { enableHighAccuracy: true })
    },
    /**
     * 获取首页定位天气信息
    */
    getInit () {
      baseData(this.AmapL[0] + ',' + this.AmapL[1]).then(res => {
        const data = res.data.result
        const _this = this.GetHome = new GetHome(data)
        const homeData = this.homeData = {
          city: this.address.province + this.address.city + this.address.district + this.address.street,
          data: {
            wind: _this.wind,
            temperature: _this.temperature,
            apparent_temperature: _this.apparent_temperature,
            humidity: _this.humidity,
            skycon: _this.skycon,
            air_desc: _this.air_desc,
            tips: _this.tips
          },
          colors: ['#7187db', '#6188da'],
          unshow: false,
          loading: false
        }
        this.$store.commit('setHomeData', homeData)
      })
    },
    /**
     * 根据经纬度获取天气信息
    */
    getWeatherInfo (lng, lat, index) {
      baseData(lng + ',' + lat).then(res => {
        const data = res.data.result
        const _this = this.GetHome = new GetHome(data)
        const weatherData = {
          wind: _this.wind,
          temperature: _this.temperature,
          apparent_temperature: _this.apparent_temperature,
          humidity: _this.humidity,
          skycon: _this.skycon,
          air_desc: _this.air_desc,
          tips: _this.tips
        }
        this.$store.commit('setListData', { index, weatherData })
      })
    }
  },
  computed: {
    ...mapState(['addressList', 'activeIndex'])
  }
}
