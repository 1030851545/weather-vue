<!--  -->
<template>
    <el-container style="height: 600px; border: 1px solid #eee">
  <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
<!-- <el-menu :default-openeds="['0']" router>
          <el-submenu v-for="(item,index) in $router.options.routes" :key="index">
            <template slot="title"><i class="el-icon-bell"></i>{{item.name}}</template>
          </el-submenu>
</el-menu> -->
  </el-aside>

  <el-container>
    <el-header style="text-align: right; font-size: 12px">
      <el-dropdown>
        <i class="el-icon-setting" style="margin-right: 15px"></i>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>查看</el-dropdown-item>
          <el-dropdown-item>新增</el-dropdown-item>
          <el-dropdown-item>删除</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

    </el-header>

    <el-main>

    </el-main>
  </el-container>

</el-container>

</template>

<script>
// import PageOne from '@/components/PageOne.vue'
// import PageTwo from '@/components/PageTwo.vue'
// import PageThree from '@/components/PageThree.vue'
export default {
  data () {
    const item = {
      date: '2016-05-02',
      name: '王小虎',
      address: '上海市普陀区金沙江路 1518 弄'
    }
    return {
      tableData: Array(20).fill(item)
    }
  },
  methods: {
    goTo (path) {
      this.$router.replace(path)
    }
  },
  components: {
    // pageone: PageOne

    // pagetwo: PageTwo
  }
}
</script>
<style lang="less">
.el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }

  .el-aside {
    color: #333;
  }
</style>
