<!--  -->
<template>
    <div class="W-container">
      <el-button  @click="winReload" icon="el-icon-refresh" size="mini" circle></el-button>
        <div class="W-chart" id="W-chart" ref="W_ref" style="width: 100%;height: 240px;">
        </div>
    </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
    }
  },
  mounted () {
    const _this = this
    axios.get('http://localhost:8088/good').then(function (response) {
      // 基于准备好的dom，初始化echarts实例

      const myChart = _this.$echarts.init(document.getElementById('W-chart'))
      // 绘制图表
      myChart.setOption(
        {
          tooltip: {
            trigger: 'item'
          },
          series: [
            {
              name: '',
              type: 'pie',
              radius: ['40%', '70%'],
              avoidLabelOverlap: false,
              itemStyle: {
                borderRadius: 10,
                borderColor: '#fff',
                borderWidth: 2
              },
              label: {
                show: true
              },
              emphasis: {
                label: {
                  show: true,
                  fontSize: '20',
                  fontWeight: 'bold'
                }
              },
              labelLine: {
                show: false
              },

              data: [
                { value: 7, name: response.data.forecasts[0].casts[0].dayweather },
                { value: 8, name: response.data.forecasts[0].casts[1].dayweather },
                { value: 9, name: response.data.forecasts[0].casts[2].dayweather },
                { value: 10, name: response.data.forecasts[0].casts[3].dayweather }
              ]
            }
          ]
        }
      )
    })
  },
  methods: {
    winReload: function (cond) {
      window.location.reload()
    }

  }
}
</script>

<style lang="less">

</style>
