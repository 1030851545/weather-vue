<template>
  <div class="hello">

<Row type="flex" justify="space-around" class-name="i-row">
        <Col span="6" class-name="Col">
          <Card :padding="0">
    <div id="HChart" class="HChart" ref="Tem_ref" style="width: 377px;height: 240px;"></div>

          </Card>
        </Col>
        <Col span="6" class-name="Col">
          <Card :padding="0">
 <div id="liquidfill-chart1" class="liquidfill-chart1" style="width: 377px;height: 240px;"></div>          </Card>
        </Col>
        <Col span="6" class-name="Col">
          <Card :padding="0">
    <div class="G-chart" id="G-chart" ref="G_ref" style="width: 377px;height: 240px;"></div>
          </Card>
        </Col>
         <Col span="5" class-name="Col">
          <Card :padding="0">
        <div class="W-chart" id="W-chart" ref="W_ref" style="width: 100%;height: 240px;"></div>
          </Card>
        </Col>
      </Row>
      <div class="citysearch">
<form class="sousuo">
      <el-autocomplete  type="text" clearable v-model="cityname"
      placeholder="请输入城市名称">
      </el-autocomplete>
      <el-button @click="cz();gz();tz();proz();minz();humz();maxz();"  v-on:click="search" icon="el-icon-search">
      </el-button>
    </form>

        <div class="jinri">
      <el-card class="tcard" shadow="hover">
        <h3>
          {{this.cityname}}实时天气
        </h3>
        <Today v-bind:result="results">
        </Today>
        <!-- 引入子组件 -->
        <div class="tod">
          <ul>
            <li v-for="result in  results" v-bind:key="result.city">
              {{result}}
            </li>
          </ul>
        </div>
      </el-card>

    </div>
    <!-- <div class="today1">
            <el-collapse v-for="result1 in  result1s" v-bind:key="result1.city" >
  <el-collapse-item >
    <template slot="title" name="result1.date">
    日期：{{result1.date}}<i class="header-icon el-icon-cloudy"></i>
      </template>
      <div>白天温度：{{result1.daytemp}}</div>
      <div>夜晚温度：{{result1.nighttemp}}</div>
      <div>白天天气：{{result1.dayweather}}</div>
      <div>夜晚天气：{{result1.nightweather}}</div>
    </el-collapse-item>
           </el-collapse>
            </div> -->

      </div>
 <el-button class="life1" type="primary" round @click="centerDialogVisible = true"><i class="el-icon-umbrella
"></i>&nbsp;生活建议</el-button>
      <el-dialog
  title="提示"
  :visible.sync="centerDialogVisible"
  width="30%"
  center>
  {{result1L[0].date}}<br>
  <p>{{result1L[0].name}}: {{result1L[0].category}}</p> <i>{{result1L[0].text}}</i>
  <br>
  <p>{{result1L[1].name}}: {{result1L[1].category}}</p> <i>{{result1L[1].text}}</i>
  <p>{{result1L[2].name}}: {{result1L[2].category}}</p> <i>{{result1L[2].text}}</i>
  <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
<el-tooltip placement="top">
  <div slot="content">  <p>{{result1L[0].name}}: {{result1L[0].category}}</p> <i>{{result1L[0].text}}</i></div>
  <el-button  type="primary" plain>运动指数</el-button>
</el-tooltip>
<el-tooltip placement="top">
  <div slot="content">  <p>{{result1L[1].name}}: {{result1L[1].category}}</p> <i>{{result1L[1].text}}</i></div>
  <el-button  type="primary" plain>穿衣指数</el-button>
</el-tooltip>
<el-tooltip placement="top">
  <div slot="content">  <p>{{result1L[2].name}}: {{result1L[2].category}}</p> <i>{{result1L[2].text}}</i></div>
  <el-button  type="primary" plain>空气指数</el-button>
</el-tooltip>
<el-tooltip placement="top">
  <div slot="content">  <p>{{result1Ls.title}}: {{result1Ls.description}}</p> <i>{{result1L[0].text}}</i></div>
  <el-button type="warning" plain>天气预警</el-button>
</el-tooltip>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import Today from '@/components/Today.vue'

export default {
  name: 'HelloWorld',
  components: {
    Today
  },
  data () {
    return {
      cityname: '',
      city: {
        name: ''
      },
      centerDialogVisible: false,
      results: [],
      result1L: [],
      resultsz: [],
      result1Ls: []
    }
  },
  mounted () {

  },
  created () {
    var l = 'http://localhost:8088/life'
    var z = 'http://localhost:8088/zhishu'
    var _this = this
    _this.$axios.get(l).then(function (responseL) {
      _this.result1L = responseL.data.daily
      console.log(_this.result1L)
    })
    _this.$axios.get(z).then(function (responseZ) {
      _this.result1Ls = responseZ.data.results[0].alarms[0]
      console.log(_this.result1Ls)
    })
  },
  computed: mapState(['citys']),
  methods: {

    cz () {
      this.$emit('cz', this.cityname)
    },
    gz () {
      this.$emit('gz', this.results.temperature)
    },
    tz () {
      this.$emit('tz', this.results.reporttime)
    },
    proz () {
      this.$emit('proz', this.results.province)
    },
    maxz () {
      this.$emit('maxz', this.result1s[0].daytemp)
    },
    minz () {
      this.$emit('minz', this.result1s[0].nighttemp)
    },
    humz () {
      this.$emit('humz', this.results.humidity)
    },

    search: function () {
      var _this = this
      var a = 'http://localhost:8088/query'
      var d = 'http://localhost:8088/good'
      // var z = 'http://localhost:8088/zhishu'
      var c = _this.cityname
      var b = {
        params: {
          city: c
        }
      }
      // _this.$axios.get(l).then(function (responseL) {
      //   _this.result1L = responseL.data.daily
      //   console.log(_this.result1L)
      // })
      // _this.$$axios.get(z, b).then(function (responsezh) {
      //   _this.resultsz = responsezh.data
      //   console.log(_this.resultsz)
      // })

      _this.$axios.get(d, b).then(function (response1) {
        _this.result1s = response1.data.forecasts[0].casts
        console.log(_this.result1s)
        const myChart2 = _this.$echarts.init(document.getElementById('W-chart'))
        // 绘制图表
        myChart2.setOption(
          {
            tooltip: {
              trigger: 'item'
            },
            series: [
              {
                name: '',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                  borderRadius: 10,
                  borderColor: '#fff',
                  borderWidth: 2
                },
                label: {
                  show: true
                },
                emphasis: {
                  label: {
                    show: true,
                    fontSize: '20',
                    fontWeight: 'bold'
                  }
                },
                labelLine: {
                  show: false
                },

                data: [
                  { value: response1.data.forecasts[0].casts[0].week, name: response1.data.forecasts[0].casts[0].dayweather },
                  { value: response1.data.forecasts[0].casts[1].week, name: response1.data.forecasts[0].casts[1].dayweather },
                  { value: response1.data.forecasts[0].casts[2].week, name: response1.data.forecasts[0].casts[2].dayweather },
                  { value: response1.data.forecasts[0].casts[3].week, name: response1.data.forecasts[0].casts[3].dayweather }
                ]
              }
            ]
          }
        )

        const myChart = _this.$echarts.init(document.getElementById('HChart'))
        // 绘制图表
        myChart.setOption({

          tooltip: {
            trigger: 'axis'
          },
          legend: {
            data: ['最高气温', '最低气温']
          },

          xAxis: {
            type: 'category',
            boundaryGap: false,
            data: [response1.data.forecasts[0].casts[0].date,
              response1.data.forecasts[0].casts[1].date,
              response1.data.forecasts[0].casts[2].date,
              response1.data.forecasts[0].casts[3].date]
          },
          yAxis: {
            type: 'value',
            axisLabel: {
              formatter: '{value} °C'
            }
          },
          series: [
            {
              name: '最高气温',
              type: 'line',
              data: [response1.data.forecasts[0].casts[0].daytemp,
                response1.data.forecasts[0].casts[1].daytemp,
                response1.data.forecasts[0].casts[2].daytemp,
                response1.data.forecasts[0].casts[3].daytemp],
              markPoint: {
                data: [
                  { type: 'max', name: '最大值' },
                  { type: 'min', name: '最小值' }
                ]
              },
              markLine: {
                data: [
                  { type: 'average', name: '平均值' }
                ]
              }
            },
            {
              name: '最低气温',
              type: 'line',
              data: [response1.data.forecasts[0].casts[0].nighttemp,
                response1.data.forecasts[0].casts[1].nighttemp,
                response1.data.forecasts[0].casts[2].nighttemp,
                response1.data.forecasts[0].casts[3].nighttemp],
              markPoint: {
                data: [
                  { name: '周最低', value: -2, xAxis: 1, yAxis: -1.5 }
                ]
              },
              markLine: {
                data: [
                  { type: 'average', name: '平均值' },
                  [{
                    symbol: 'none',
                    x: '90%',
                    yAxis: 'max'
                  }, {
                    symbol: 'circle',
                    label: {
                      position: 'start',
                      formatter: '最大值'
                    },
                    type: 'max',
                    name: '最高点'
                  }]
                ]
              }
            }
          ]
        })
      })

      _this.$axios.get(a, b).then(function (response) {
        _this.results = response.data.lives[0]
        console.log(_this.results)
        console.log(response.data.lives[0].city)
        console.log('温度' + response.data.lives[0].temperature)
        console.log('湿度' + response.data.lives[0].humidity)
        console.log('天气' + response.data.lives[0].weather)
        const myChart = _this.$echarts.init(document.getElementById('liquidfill-chart1'))
        // 绘制图表
        myChart.setOption({
          title: {
            text: '空气湿度',
            textStyle: {
              fontSize: 14
            }
          },
          series: [{

            type: 'liquidFill',
            radius: '65%',
            data: [{
              name: 'First Data',
              value: response.data.lives[0].humidity
            }, 0.5, 0.4, 0.3],
            label: {
              normal: {
                formatter: '{c}%',
                textStyle: {
                  fontSize: 50
                }
              }
            }
          }]
        })

        const myChart1 = _this.$echarts.init(document.getElementById('G-chart'))
        // 绘制图表
        myChart1.setOption({
          title: {
            text: '温度仪表盘',
            textStyle: {
              fontSize: 14
            }
          },
          series: [{
            type: 'gauge',
            min: -10,
            max: 40,
            axisLine: {
              lineStyle: {
                width: 20,
                color: [
                  [0.2, '#0099FF'],
                  [0.5, '#4dabf7'],
                  [0.65, '#69db7c'],
                  [0.8, '#ffa94d'],
                  [1, '#ff6b6b']
                ]
              }
            },
            pointer: {
              itemStyle: {
                color: 'auto'
              }
            },
            axisTick: {
              distance: -30,
              length: 14,
              lineStyle: {
                color: '#fff',
                width: 2
              }
            },
            splitLine: {
              distance: -30,
              length: 51,
              lineStyle: {
                color: '#fff',
                width: 2
              }
            },
            axisLabel: {
              color: 'auto',
              distance: 2,
              fontSize: 15
            },
            detail: {
              valueAnimation: true,
              formatter: '{value} ℃',
              fontSize: 22,
              color: 'auto'
            },
            data: [{
              value: response.data.lives[0].temperature
            }]
          }]
        })
      })
    }
  }
}
</script>

<style>

li{
  list-style-type: none;
  font-family: "PingFang SC";

}
.sousuo{
  text-align: center;
}
.hello{
  height: 100%;
}
.tod{
  position: relative;
  bottom: 150px;
 float: right;
}
.jinri{
  padding-top: 40px;
  z-index: 1;
}
.tcard{
  width: 377px;
  height: 240px;
}
.citysearch{
  position: absolute;
  left:1128px;
  bottom: 355px;
}
.life1{
  position: relative;
  bottom:330px;
  float: right;
  right: 160px;
}
</style>
