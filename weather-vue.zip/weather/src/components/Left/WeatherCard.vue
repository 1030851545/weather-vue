<template>
  <transition>
    <div :class="['list-cart', {'selected': selected}]" v-if="MixinGetObjKey(liData.data, 'skycon')">
      <div class="list-head">
        <span class="head-icon">
          <i :style="{color: liData.colors[1]}"></i>
        </span>
        <p class="head-title">广西壮族自治区 桂林市七星区</p><i class="el-icon-s-promotion"></i>
      </div>
      <div class="list-body">
        <div class="skycon"><i :class="['fas', skycon_icon(liData.data.skycon)]"></i>{{liData.data.skycon | skycon}}</div>
        <div class="temperature">
          <div class="box-left">{{liData.data.temperature | temperature}}</div>
          <div class="box-right">
            <div class="top">°</div>
            <div class="bottom">体感 {{liData.data.apparent_temperature | temperature}}°</div>
          </div>
        </div>
        <div class="more-info">
          <div class="direction" v-if="MixinGetObjKey(liData.data, 'wind', 'direction')">{{liData.data.wind.direction | windDir}}</div>
          <div class="humidity">湿度 {{liData.data.humidity | humidity}}</div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'ListCart',
  data () {
    return {
      show: true
    }
  },
  props: {
    liData: {
      type: Object,
      default () {
        return {}
      }
    },
    selected: Boolean
  },
  methods: {
    skycon_icon (value) {
      let desc = ''
      switch (value) {
        case 'CLEAR_DAY':
          desc = 'sun' // （白天）
          break
        case 'CLEAR_NIGHT':
          desc = 'moon' // （夜间）
          break
        case 'PARTLY_CLOUDY_DAY':
          desc = 'cloud' // （白天）
          break
        case 'PARTLY_CLOUDY_NIGHT':
          desc = 'cloud' // （夜间）
          break
        case 'CLOUDY':
          desc = 'cloud-sun'
          break
        case 'LIGHT_HAZE':
          desc = 'smog'
          break
        case 'MODERATE_HAZE':
          desc = 'smog'
          break
        case 'HEAVY_HAZE':
          desc = 'smog'
          break
        case 'LIGHT_RAIN':
          desc = 'cloud-showers-heavy'
          break
        case 'MODERATE_RAIN':
          desc = 'cloud-showers-heavy'
          break
        case 'HEAVY_RAIN':
          desc = 'cloud-showers-heavy'
          break
        case 'STORM_RAIN':
          desc = 'poo-storm'
          break
        case 'FOG':
          desc = 'smog'
          break
        case 'LIGHT_SNOW':
          desc = 'snowflake'
          break
        case 'MODERATE_SNOW':
          desc = 'snowflake'
          break
        case 'HEAVY_SNOW':
          desc = 'snowflake'
          break
        case 'STORM_SNOW':
          desc = 'cloud-meatball'
          break
        case 'DUST':
          desc = 'wind'
          break
        case 'SAND':
          desc = 'wind'
          break
        case 'WIND':
          desc = 'wind'
          break
      }
      return 'fa-' + desc
    },
    /**
     * 判断是否存在数据
    */
    MixinGetObjKey () {
      if (!arguments[0]) return ''
      let state = arguments[0]
      for (let i = 1; i < arguments.length; i++) {
        state = state[arguments[i]]
        if (!state) {
          state = ''
          return ''
        }
      }
      return state
    }
  },
  filters: {
    skycon (value) {
      let desc = ''
      switch (value) {
        case 'CLEAR_DAY':
          desc = '晴朗' // （白天）
          break
        case 'CLEAR_NIGHT':
          desc = '晴朗' // （夜间）
          break
        case 'PARTLY_CLOUDY_DAY':
          desc = '多云' // （白天）
          break
        case 'PARTLY_CLOUDY_NIGHT':
          desc = '多云' // （夜间）
          break
        case 'CLOUDY':
          desc = '阴'
          break
        case 'LIGHT_HAZE':
          desc = '轻度雾霾'
          break
        case 'MODERATE_HAZE':
          desc = '中度雾霾'
          break
        case 'HEAVY_HAZE':
          desc = '重度雾霾'
          break
        case 'LIGHT_RAIN':
          desc = '小雨'
          break
        case 'MODERATE_RAIN':
          desc = '中雨'
          break
        case 'HEAVY_RAIN':
          desc = '大雨'
          break
        case 'STORM_RAIN':
          desc = '暴雨'
          break
        case 'FOG':
          desc = '雾'
          break
        case 'LIGHT_SNOW':
          desc = '小雪'
          break
        case 'MODERATE_SNOW':
          desc = '中雪'
          break
        case 'HEAVY_SNOW':
          desc = '大雪'
          break
        case 'STORM_SNOW':
          desc = '暴雪'
          break
        case 'DUST':
          desc = '浮尘'
          break
        case 'SAND':
          desc = '沙尘'
          break
        case 'WIND':
          desc = '大风'
          break
      }
      return desc
    },
    temperature (value) {
      return Math.floor(value)
    },
    humidity (value) {
      return (value * 100).toFixed(0) + '%'
    },
    windDir (value) {
      if (value < 90) {
        return '东北风'
      } else if (value === 90) {
        return '东风'
      } else if (value < 180) {
        return '东南风'
      } else if (value === 180) {
        return '南风'
      } else if (value < 270) {
        return '西南风'
      } else if (value === 270) {
        return '西风'
      } else if (value < 360) {
        return '西北风'
      } else if (value === 360) {
        return '北风'
      }
    }
  },
  created () {
  },
  mounted () {
    /**
     * 等待动画效果结束取消动画 Class
    */
    if (!this.liData.loading) {
      setTimeout(() => {
        this.show = this.selected
      }, 600)
    }
  }
}
</script>

<style lang="less" scoped>
.list-cart {
  width: 100%;
  height: 40%;
  margin: 0 ;
  background: white;
  border-radius: 8px;
  box-shadow: 0 10px 10px rgba(0, 0, 0, .24);
  .list-head {
    padding: 10px;
    display: flex;
    align-items: center;
    box-sizing: border-box;
  .head-title {
      margin-left: 24px;
      color: #333;
      overflow: hidden;
    }
  }
  .list-body {
    color: #3e3e3e;
  .skycon {
      margin-top: 12px;
      text-align: center;
    }
    .temperature {
      display: flex;
      margin: 0;
      justify-content: center;
      .box-left {
        font-size: 64px;
      }
      .box-right {
        display: flex;
        position: relative;
        .top {
          font-size: 48px;
        }
        .bottom {
          border-radius: 10px;
          position: absolute;
          bottom: 12px;
          width: 60px;
          right: -50px;
        }
      }
    }
    .more-info {
      display: flex;
      justify-content: center;
      div {
        margin: 0 4px;
      }
    }
  }
}

</style>
