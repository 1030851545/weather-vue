<template>
 <div class='com-container'>
<el-tabs :tab-position="tabPosition" style="height: 500px;">
    <el-tab-pane label="温度图" ><div class='com-chart' ref='map_ref'></div></el-tab-pane>
    <el-tab-pane label="数据图" >

 <el-table
      :data="tableData"
      style="width: 100%;"
      max-height="290"
       >
      <el-table-column
        prop="id"
        label="ID"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        label="名称"
        width="180">
      </el-table-column>
      <el-table-column
        prop="temp"
        label="温度℃">
      </el-table-column>
       <el-table-column
      label="操作">
 <template slot-scope="scope">
                <el-button @click="cityDelete(scope.row)" type="text" size="small">删除</el-button>
                <el-button @click="findCity(scope.row)" type="text" size="small">编辑</el-button>
            </template>
    </el-table-column>
    </el-table>
       <el-form ref="addcity" :model="city"  label-width="80px" style="width: 300px">
       <el-form-item label="名称"  prop="name">
            <el-input size="mini" v-model="city.name"></el-input>
        </el-form-item>
        <el-form-item label="温度" prop="temp">
            <el-input size="mini" v-model.number="city.temp" value="gz"></el-input>
        </el-form-item>
        <el-form-item>
           <el-button type="success" size="mini" :loading="true" >地图加载中</el-button>
            <el-button class="el-icon-document-add" type="success" size="mini" @click="onSubmit('addcity')" >收藏</el-button>
            <el-button-group>
            <el-button type="primary" size="mini" icon="el-icon-heavy-rain" @click="dialogVisible = true">添加湿度</el-button>
            <el-button class="addwendu" type="warning" size="mini" icon="el-icon-sunny" @click="dialogVisible1 = true">添加温度</el-button>
            </el-button-group>
        </el-form-item>
    </el-form>

    </el-tab-pane>
    <el-tab-pane label="热力图"><div style="width:485px;height:490px;">
        <iframe src="https://map.qweather.com/" id="mobsf" style="width:610px;height:490px;border:1px solid #fff;border-radius:10px;" scrolling="no" frameborder="0" ></iframe>
    </div></el-tab-pane>
  </el-tabs>
<el-dialog
  title="提示"
  :visible.sync="dialogVisible"

  :before-close="handleClose">
   <el-form ref="addhum" :model="humidity" label-width="80px" style="width: 600px">

        <el-form-item label="名称" prop="name">
            <el-input v-model="humidity.name"></el-input>
        </el-form-item>
                <el-form-item label="省份" prop="shengfen">
            <el-input v-model="humidity.shengfen"></el-input>
        </el-form-item>
        <el-form-item label="湿度" prop="humidity">
            <el-input v-model.number="humidity.humidity"></el-input>
        </el-form-item>
                <el-form-item label="时间" prop="time">
            <el-input v-model="humidity.time"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary"  @click="onSubmith('addhum')">立即添加</el-button>
 <el-button @click="dialogVisible = false">取 消</el-button>
        </el-form-item>
    </el-form>
</el-dialog>
<el-dialog
  title="提示"
  :visible.sync="dialogVisible1"

  :before-close="handleClose">
   <el-form ref="addwen" :model="wendu" label-width="80px" style="width: 600px">

        <el-form-item label="名称" prop="name">
            <el-input v-model="wendu.name"></el-input>
        </el-form-item>
                <el-form-item label="省份" prop="shengfen">
            <el-input v-model="wendu.shengfen"></el-input>
        </el-form-item>
        <el-form-item label="最低温度" prop="min">
            <el-input v-model.number="wendu.min"></el-input>
        </el-form-item>
          <el-form-item label="最高温度" prop="max">
            <el-input v-model.number="wendu.max"></el-input>
        </el-form-item>
                <el-form-item label="时间" prop="time">
            <el-input v-model="wendu.time"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary"  @click="onSubmitw('addwen')">立即添加</el-button>
             <el-button @click="dialogVisible1 = false">取 消</el-button>
        </el-form-item>
    </el-form>
</el-dialog>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  props: { gz: String, cz: String, tz: String, proz: String, minz: String, humz: String, maxz: String },
  data () {
    return {
      tabPosition: 'left',
      allData: null,
      dialogVisible: false,
      dialogVisible1: false,
      mapData: {},
      city: {
        name: this.cz,
        temp: this.gz
      },
      wendu: {
        name: this.cz,
        shengfen: this.proz,
        min: this.minz,
        max: this.maxz,
        time: this.tz
      },
      humidity: {
        name: this.cz,
        shengfen: this.proz,
        humidity: this.humz,
        time: this.tz
      },
      chartInstance: null,
      tableData: [],
      arr: [],
      obj: {},
      arr2: []
    }
  },
  mounted () {
    this.initChart()
  },
  watch: {
    cz (newValue) {
      this.city.name = newValue
      this.humidity.name = newValue
      this.wendu.name = newValue
    },
    gz (newValue1) {
      this.city.temp = newValue1
    },
    tz (newValue2) {
      this.wendu.time = newValue2
      this.humidity.time = newValue2
    },
    proz (newValue3) {
      this.humidity.shengfen = newValue3
      this.wendu.shengfen = newValue3
    },
    minz (newValue4) {
      this.wendu.min = newValue4
    },
    humz (newValue5) {
      this.humidity.humidity = newValue5
    },
    maxz (newValue6) {
      this.wendu.max = newValue6
    }
  },
  created () {
    const _this = this
    const id = this.$route.query.id
    axios.get('http://localhost:8088/city/find/' + id).then(function (responsec) {
      _this.city = responsec.data
    })
    axios.get('http://localhost:8088/city/list').then(function (response) {
      _this.tableData = response.data
      console.log(response.data[0].temp)
      console.log(response.data)
      // var arr = response.data[0].temp\

      response.data.forEach(function (i, index) {
        const obj = {}
        console.log('?' + index)
        console.log('id' + i.id)
        console.log(i.name)
        obj.name = i.name
        obj.value = i.temp
        _this.arr.push(obj)
        _this.arr2.push(i.temp)
      })
      console.log(_this.arr)
      console.log(_this.arr2)
      // this.chartInstance.setOption({
      //   series: [{
      //     data: [
      //       {
      //         name: _this.arr[0],
      //         data: _this.arr2[0]
      //       }
      //     ]
      //   }]
      // })
    })
  },
  methods: {
    handleClose (done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
        })
        .catch(_ => {})
    },
    findCity (object) {
      this.$router.push('/edit?id=' + object.id)
    },
    async initChart () {
      this.chartInstance = this.$echarts.init(this.$refs.map_ref, this.theme)
      const ret = await axios.get('http://localhost:8999/static/map/china.json')
      this.$echarts.registerMap('china', ret.data)
      const initOption = {
        title: {
          text: '全国温度',
          left: 10,
          top: 10
        },
        tooltip: {
          show: true,
          formatter: '{b}</br>当前温度：{c}℃'
        },
        geo: {
          type: 'map',
          map: 'china',
          top: '5%',
          bottom: '5%',
          roam: false, // true允许地图缩放
          itemStyle: {
            areaColor: '#fff',
            borderColor: '#555'
          },
          label: {
            show: true
          }
        },
        legend: {
          left: '5%',
          bottom: '5%',
          orient: 'vertical'
        },
        series: [
          {
            data:
              this.arr,
            geoIndex: 0,
            type: 'map'
          }
        ],
        visualMap: {
          pieces: [
            { min: 40 },
            { min: 30, max: 39 },
            { min: 20, max: 29 },
            { min: 10, max: 19 },
            { min: 1, max: 9 },
            { min: -10, max: 0 },
            { max: -11 }
          ],
          inRange: {
            color: ['#4297F1', 'white']
          }
        }
      }
      this.chartInstance.setOption(initOption)
    },
    onSubmit1 (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const _this = this
          axios.put('http://localhost:8088/city/update', this.city).then(function (responsec) {
            if (responsec.data) {
              _this.$alert(_this.city.name + '修改成功！', '修改数据', {
                confirmButtonText: '确定',
                callback: action => {
                  _this.$router.push('/')
                }
              })
            }
          })
        }
      })
    },
    onSubmit (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const _this = this
          axios.post('http://localhost:8088/city/add', this.city).then(function (response3) {
            if (response3.data) {
              _this.$alert(_this.city.name + '添加成功！', '添加数据', {
                confirmButtonText: '确定',
                callback: action => {
                  location.reload()
                }
              })
            }
          })
        }
      })
    },
    onSubmith (addhum) {
      this.$refs[addhum].validate((valid1) => {
        if (valid1) {
          const _this = this
          axios.post('http://localhost:8088/humidity/add', this.humidity).then(function (responseh) {
            if (responseh.data) {
              _this.$alert(_this.humidity.name + '湿度添加成功！', '添加数据', {
                confirmButtonText: '确定',
                callback: action => {
                }
              })
            }
          })
        }
      })
    },
    onSubmitw (addwen) {
      this.$refs[addwen].validate((valid2) => {
        if (valid2) {
          const _this = this
          axios.post('http://localhost:8088/wendu/add', this.wendu).then(function (responsew) {
            if (responsew.data) {
              _this.$alert(_this.wendu.name + '温度添加成功！', '添加数据', {
                confirmButtonText: '确定',
                callback: action => {
                }
              })
            }
          })
        }
      })
    },
    cityDelete (object) {
      const _this = this

      this.$confirm('是否确定要删除' + object.name + '？', '删除数据', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        axios.delete('http://localhost:8088/city/delete/' + object.id).then(function (response) {
          if (response.data) {
            _this.$alert(object.name + '删除成功！', '删除数据', {
              confirmButtonText: '确定',
              callback: action => {
                location.reload()
              }
            })
          }
        })
      }).catch(() => {

      })
    }
  }
}
</script>

<style lang='less' scoped>
.com-container {
  width:  685px;
  height:  490px;

}

.com-chart {
 width:  585px;
  height:  490px;

}
.addwendu{
  position: relative;
  left: 20px;
}
</style>
