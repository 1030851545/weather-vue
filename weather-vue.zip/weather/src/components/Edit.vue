<template>
    <el-form ref="form" :model="city" label-width="80px" style="width: 600px">
        <el-form-item label="城市ID">
            <el-input v-model="city.id" readonly></el-input>
        </el-form-item>
        <el-form-item label="名称" prop="name">
            <el-input v-model="city.name"></el-input>
        </el-form-item>
        <el-form-item label="温度℃" prop="sale">
            <el-input v-model.number="city.temp"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="onSubmit('form')">立即修改</el-button>
            <el-button @click="backk">取消</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Edit',
  data () {
    return {
      city: {
        name: '',
        temp: ''
      }
    }
  },
  created () {
    const id = this.$route.query.id
    const _this = this
    axios.get('http://localhost:8088/city/find/' + id).then(function (response) {
      _this.city = response.data
    })
  },
  methods: {
    onSubmit (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const _this = this
          axios.put('http://localhost:8088/city/update', this.city).then(function (response) {
            if (response.data) {
              _this.$alert(_this.city.name + '修改成功！', '修改数据', {
                confirmButtonText: '确定',
                callback: action => {
                  _this.$router.push('/')
                }
              })
            }
          })
        }
      })
    },
    backk () {
      this.$router.push('/')
    }
  }
}
</script>

<style scoped>

</style>
