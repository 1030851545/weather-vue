<!--  -->
<template>
  <div>
     <el-table
      :data="tableData"
      style="width: 100%;"
      max-height="290"
       >
      <el-table-column
        prop="id"
        label="ID"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        label="名称"
        width="180">
      </el-table-column>
      <el-table-column
        prop="shengfen"
        label="温度℃">
      </el-table-column>

         <el-table-column
        prop="humidity"
        label="温度℃">
      </el-table-column>
         <el-table-column
        prop="time"
        label="温度℃">
      </el-table-column>
       <el-table-column
      label="操作">
 <template >

                <el-button  type="text" size="small">删除</el-button>
                <el-button type="text"  size="small">编辑</el-button>
            </template>
    </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
      tableData: []
    }
  },
  created () {
    const _this = this
    axios.get('http://localhost:8088/wHumidity/list').then(function (response) {
      _this.tableData = response.data
    })
  },
  methods: {

  }

}

</script>

<style lang='less' scoped>
</style>
