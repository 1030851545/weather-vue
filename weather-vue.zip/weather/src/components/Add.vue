<template>
    <el-form ref="fruitRules" :model="humidity"  label-width="80px" class="demo-ruleForm" style="width: 600px">
        <el-form-item label="名称" prop="name">
            <el-input v-model="humidity.name"></el-input>
        </el-form-item>
        <el-form-item label="销量" prop="sale">
            <el-input v-model.number="humidity.humidity"></el-input>
        </el-form-item>

        <el-form-item>
            <el-button type="primary" @click="onSubmit('fruitRules')">立即创建</el-button>
            <el-button>取消</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Add',
  data () {
    return {
      humidity: {
        name: '',
        humidity: ''
      }
    }
  },
  methods: {
    onSubmit (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const _this = this
          axios.post('http://localhost:8088/humidity/add', this.humidity).then(function (response) {
            if (response.data) {
              _this.$alert(_this.humidity.name + '添加成功！', '添加数据', {
                confirmButtonText: '确定',
                callback: action => {

                }
              })
            }
          })
        }
      })
    }
  }
}
</script>

<style scoped>

</style>
