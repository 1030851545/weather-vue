<template>
  <div>
    <div class="wid">
      <ul>
        <li>省份</li>
        <li>城市</li>
        <li>编号</li>
        <li>天气</li>
        <li>温度</li>
        <li>风向</li>
        <li>风速</li>
        <li>湿度</li>
        <li>时间</li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {

}
</script>
