<template>
  <div>
    <div class="wid">
      <ul>
        <li>温度</li>
        <li>湿度</li>
        <li>天气</li>
        <li>标识id</li>
        <li>风向</li>
        <li>风力</li>
        <li>空气质量指数</li>
        <li>风力</li>
        <li>空气质量指数</li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
