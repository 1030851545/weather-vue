<template>
  <div>
    <el-button  @click="winReload" icon="el-icon-refresh" size="mini" circle></el-button>
    <div id="HChart" class="HChart" ref="Tem_ref" style="width: 100%;height: 240px;"></div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
      timer: null
    }
  },
  mounted () {
    const _this = this
    axios.get('http://localhost:8088/good').then(function (response) {
      // 基于准备好的dom，初始化echarts实例

      const myChart = _this.$echarts.init(document.getElementById('HChart'))
      // 绘制图表
      myChart.setOption({

        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['最高气温', '最低气温']
        },

        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: [response.data.forecasts[0].casts[0].date,
            response.data.forecasts[0].casts[1].date,
            response.data.forecasts[0].casts[2].date,
            response.data.forecasts[0].casts[3].date]
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: '{value} °C'
          }
        },
        series: [
          {
            name: '最高气温',
            type: 'line',
            data: [response.data.forecasts[0].casts[0].daytemp,
              response.data.forecasts[0].casts[1].daytemp,
              response.data.forecasts[0].casts[2].daytemp,
              response.data.forecasts[0].casts[3].daytemp],
            markPoint: {
              data: [
                { type: 'max', name: '最大值' },
                { type: 'min', name: '最小值' }
              ]
            },
            markLine: {
              data: [
                { type: 'average', name: '平均值' }
              ]
            }
          },
          {
            name: '最低气温',
            type: 'line',
            data: [response.data.forecasts[0].casts[0].nighttemp,
              response.data.forecasts[0].casts[1].nighttemp,
              response.data.forecasts[0].casts[2].nighttemp,
              response.data.forecasts[0].casts[3].nighttemp],
            markPoint: {
              data: [
                { name: '周最低', value: -2, xAxis: 1, yAxis: -1.5 }
              ]
            },
            markLine: {
              data: [
                { type: 'average', name: '平均值' },
                [{
                  symbol: 'none',
                  x: '90%',
                  yAxis: 'max'
                }, {
                  symbol: 'circle',
                  label: {
                    position: 'start',
                    formatter: '最大值'
                  },
                  type: 'max',
                  name: '最高点'
                }]
              ]
            }
          }
        ]
      })
    })
  },
  methods: {
    winReload: function (cond) {
      window.location.reload()
    }
  }

}
</script>

<style lang="less">
#HChart{
  height: 1rem;
}
</style>
