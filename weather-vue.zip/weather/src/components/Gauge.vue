<!--  -->
<template>
    <div class="G-container">
      <el-button  @click="winReload" icon="el-icon-refresh" size="mini" circle></el-button>
        <div class="G-chart" id="G-chart" ref="G_ref" style="width: 100%;height: 240px;"></div>
    </div>
</template>

<script>
import axios from 'axios'

export default {
  props: ['cz'],
  data () {
    return {

    }
  },
  mounted () {
    const _this = this
    axios.get('http://localhost:8088/query').then(function (response) {
      // 基于准备好的dom，初始化echarts实例
      console.log('搜索出' + response.data.result.city)
      const myChart = _this.$echarts.init(document.getElementById('G-chart'))
      // 绘制图表
      myChart.setOption({
        title: {
          text: '温度仪表盘',
          textStyle: {
            fontSize: 14
          }
        },
        series: [{
          type: 'gauge',
          min: -10,
          max: 40,
          axisLine: {
            lineStyle: {
              width: 20,
              color: [
                [0.2, '#0099FF'],
                [0.5, '#4dabf7'],
                [0.65, '#69db7c'],
                [0.8, '#ffa94d'],
                [1, '#ff6b6b']
              ]
            }
          },
          pointer: {
            itemStyle: {
              color: 'auto'
            }
          },
          axisTick: {
            distance: -30,
            length: 14,
            lineStyle: {
              color: '#fff',
              width: 2
            }
          },
          splitLine: {
            distance: -30,
            length: 51,
            lineStyle: {
              color: '#fff',
              width: 2
            }
          },
          axisLabel: {
            color: 'auto',
            distance: 2,
            fontSize: 15
          },
          detail: {
            valueAnimation: true,
            formatter: '{value} ℃',
            fontSize: 22,
            color: 'auto'
          },
          data: [{
            value: response.data.result.realtime.temperature
          }]
        }]
      })
    })
  },
  methods: {
    winReload: function (cond) {
      window.location.reload()
    }
  }
}
</script>
