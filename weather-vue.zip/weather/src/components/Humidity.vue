<template>
<div>
  <el-button  @click="winReload" icon="el-icon-refresh" size="mini" circle></el-button>
    <div id="liquidfill-chart" class="liquidfill-chart" ref="hum_ref" style="width: 100%;height: 240px;">
    </div>
</div>
</template>
<script>
import axios from 'axios'

export default {
  data () {
    return {
    }
  },

  mounted () {
    const _this = this
    axios.get('http://localhost:8088/query').then(function (response) {
      // 基于准备好的dom，初始化echarts实例
      console.log(response.data.foreasts)
      const myChart = _this.$echarts.init(document.getElementById('liquidfill-char1t'))
      // 绘制图表
      myChart.setOption({
        title: {
          text: '空气湿度',
          textStyle: {
            fontSize: 14
          }
        },
        series: [{

          type: 'liquidFill',
          radius: '65%',
          data: [{
            name: 'First Data',
            value: 11
          }, 0.5, 0.4, 0.3],
          label: {
            normal: {
              formatter: '{c}%',
              textStyle: {
                fontSize: 50
              }
            }
          }
        }]
      })
    })
  },
  methods: {

    winReload: function (cond) {
      window.location.reload()
    }

  }

}
</script>
