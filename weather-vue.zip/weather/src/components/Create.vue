<template>
  <div class="Cr-container">
    <div class="Wcard" style="height: 235px">
        <ul :style="{ 'width': `${length() * 100}%` }">
            <li
              v-for="(li, index) of addressList"
              v-show="unShowCart(index)"
              :key="li.city"
              :style="{ transform: `translate3d(-${activeIndex * 100}%, 0, 0)` }">
              <weathercard
                v-if="unShowCart(index)"
                v-show="loadCart(li.loading)"
                :liData="li"/>
            </li>
          </ul>
    </div>
    <div>
  <tq></tq>
    </div>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
import WeatherCard from '@/components/Left/WeatherCard.vue'
import tianqi from '@/components/tianqi.vue'
// import SearchCard from '@/components/Left/SearchCard.vue'

export default {
  data () {
    return {}
  },
  components: {
    weathercard: WeatherCard,
    tq: tianqi
  // searchcard: SearchCard
  },
  computed: {
    ...mapState(['addressList', 'activeIndex', 'selected'])

  },
  methods: {
    ...mapMutations(['nextLi', 'prevLi']),
    /**
     * 判断是否开启定位天气展示
    */
    unShowCart (index) {
      if (this.$store.getters.getAddressList[0].unshow) {
        if (index === 0) {
          return false
        }
      }
      return true
    },
    /**
     * 判断是否开启定位天气展示，以此设定长度
    */
    length () {
      if (this.$store.getters.getAddressList[0].unshow) {
        return this.$store.getters.getAddressList.length - 1
      } else {
        return this.$store.getters.getAddressList.length
      }
    },
    /**
     * 设定 listCart 是否显示，防止数据加载后造成再次加载展示动画
    */
    loadCart (value) {
      return !value
    }

  }
}
</script>

<style lang='less' scoped>
ul li{
  list-style: none;
}
.Cr-container{
  height: 490px;
}
</style>
