<template>
    <div>
      <div id="he-plugin-standard"></div>
    </div>
</template>

<script>

export default {
  data () {
  },
  created () {
    // eslint-disable-next-line no-unused-expressions
    window.WIDGET = {
      CONFIG: {
        layout: '2',
        width: '375',
        height: '255',
        background: '4',
        dataColor: '000000',
        backgroundColor: 'FFFFFF',
        borderRadius: '5',
        key: 'b1d1e45f28174895941432b80b1cfe1d'
      }
    };
    (function (d) {
      var c = d.createElement('link')
      c.rel = 'stylesheet'
      c.href = 'https://widget.heweather.net/standard/static/css/he-standard.css?v=1.4.0'
      var s = d.createElement('script')
      // s.src = '../components/he-standard.js'
      s.src = 'https://widget.heweather.net/standard/static/js/he-standard.js?v=1.4.0'
      var sn = d.getElementsByTagName('script')[0]
      sn.parentNode.insertBefore(c, sn)
      sn.parentNode.insertBefore(s, sn)
    })(document)
  }
}
</script>
