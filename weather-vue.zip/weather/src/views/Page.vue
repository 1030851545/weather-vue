<template>
  <div class="page">
        <div class="header">
      <h1 class="title">实时监控系统{{cz}}</h1>
      <span class="datetime">
       {{ date }}{{ time }}
      </span>
        </div>
        <div class="main">
          <Row type="flex" justify="space-around" class-name="i-row">
        <Col span="6" class-name="Col">
          <Card :padding="0">
            <create></create>
          </Card>
        </Col>
        <Col span="11" class-name="Col">
          <Card :padding="0">
            <map1 :cz="cz" :gz="gz" :tz="tz" :maxz="maxz" :proz="proz" :minz="minz" :humz="humz"></map1>
            <!-- :hz="hz" :maxz="maxz" :minz="minz" :prz="prz" -->
          </Card>
        </Col>
        <Col span="6" class-name="Col">
          <Card :padding="0" style="height:490px">

          </Card>
        </Col>
      </Row>
        </div>
        <div>
          <search @cz="getcz" @gz="getgz" @tz="gettz" @proz="getproz" @minz="getminz" @humz="gethumz" @maxz="getmaxz" ></search>
           <!-- @minz="getminz"  @humz="gethumz" @proz="getproz" -->

        </div>

  </div>
</template>

<script>
import { AmapMixin } from '@/common/mixin.js'
import Create from '@/components/Create.vue'
import Search from '@/components/Search.vue'
import MapView from '@/components/MapView.vue'
// import tianqi from '@/components/tianqi.vue'

export default {
  mixins: [AmapMixin],
  data () {
    return {
      time: '',
      date: '',
      week: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
      cz: '',
      tz: '',
      gz: '',
      proz: '',
      humz: '',
      minz: '',
      maxz: ''
    }
  },
  mounted () {
    setInterval(() => {
      this.updateTime()
    }, 1000)
    this.updateTime()
  },
  created () {
    const list = this.addressList
    if (!list[0].unshow) { // 判断是否开启定位天气展示
      this.getLocation() // 获取定位信息
    }
  },
  methods: {
    getcz (e) {
      console.log('传递' + e)
      this.cz = e
    },
    getgz (t) {
      console.log('温度传递' + t)
      this.gz = t
    },
    gettz (a) {
      console.log('哈哈传递' + a)
      this.tz = a
    },
    getproz (j) {
      console.log('最大传递' + j)
      this.proz = j
    },
    getminz (k) {
      this.minz = k
    },
    gethumz (l) {
      this.humz = l
    },
    getmaxz (q) {
      this.maxz = q
    },
    updateTime () {
      var cd = new Date()
      this.time = this.zeroPadding(cd.getHours(), 2) + ':' + this.zeroPadding(cd.getMinutes(), 2) + ':' + this.zeroPadding(cd.getSeconds(), 2)
      this.date = this.zeroPadding(cd.getFullYear(), 4) + '-' + this.zeroPadding(cd.getMonth() + 1, 2) + '-' + this.zeroPadding(cd.getDate(), 2) + ' ' + this.week[cd.getDay()]
    },
    zeroPadding (num, digit) {
      var zero = ''
      for (var i = 0; i < digit; i++) {
        zero += '0'
      }
      return (zero + num).slice(-digit)
    },
    handleCurrentChange (val) {
      this.currentPage = val
    }
  },
  components: {
    create: Create,
    search: Search,
    map1: MapView
  // tq: tianqi
  }
}
</script>

<style lang='less'>
*{
  box-sizing:border-box;
  margin: 0;
  padding: 0;
}
.html, body{
  width: 100%;
  height: 100%;
}
.title{
  font-size: 20px;
}
.page{
  font-family: "PingFang SC";
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,.1);
  overflow: hidden;
}
.header{
  position: relative;
  text-align: center;
  line-height: 24px;
  background-color: #4297F1;
  color: #fff;
  letter-spacing: 3px;
}
.datetime{
  font-size: 10px;
}
.bottom{
  background-color: rgba(0,0,0,.1);
  padding: 6px;
}
.main{
  padding: 5px;
}
.ivu-card-bordered{
  border: none;
}
</style>
