<template>
  <div ref="myChart"></div>
</template>

<script>
export default {
  name: 'echarts',
  props: ['type', 'width', 'height', 'options'],
  data () {
    return {
      init: false,
      opts: null
    }
  },
  watch: {
    opts (val) {
      const echarts = require('echarts/lib/echarts')
      require('echarts/lib/chart/bar')
      require('echarts/lib/chart/line')
      let myChart
      if (this.init) {
        myChart = echarts.getInstanceByDom(this.$refs.myChart)
      }
      myChart.setOption(val, true)
    },
    options (val) {
      this.opts = val
    }
  },
  mounted () {
    this.opts = this.options
    this.$refs.myChart.style.width = this.width + 'px'
    this.$refs.myChart.style.height = this.height + 'px'
  }
}
</script>
