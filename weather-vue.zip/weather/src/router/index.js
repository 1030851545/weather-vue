import Vue from 'vue'
import VueRouter from 'vue-router'
import Page from '@/views/Page.vue'
import Humidity from '@/components/Humidity.vue'
import Weather from '@/components/Weather.vue'
import Gauge from '@/components/Gauge.vue'
import Temperature from '@/components/Temperature.vue'
import Create from '@/components/Create.vue'
import tianqi from '@/components/tianqi.vue'
import Search from '@/components/Search.vue'
import Tt from '@/components/Tt.vue'
import Edit from '@/components/Edit.vue'
import Add from '@/components/Add.vue'
import MapView from '@/components/MapView.vue'
import PageOne from '@/components/PageOne.vue'
import PageTwo from '@/components/PageTwo.vue'
import PageThree from '@/components/PageThree.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '',
    name: 'Page',
    component: Page
  },
  {
    path: '/hum',
    component: Humidity
  },
  {
    path: '/tianqi',
    component: Weather
  },
  {
    path: '/wendu',
    component: Temperature
  },
  {
    path: '/gauge',
    component: Gauge
  },
  {
    path: '/card',
    component: Create
  },
  {
    path: '/ss',
    name: 'search',
    component: Search
  },
  {
    path: '/tt',
    name: '数据管理',
    component: Tt
  },
  {
    path: '/tianqi1',
    component: tianqi
  },
  {
    path: '/pagetwo',
    name: '全国湿度',
    component: PageTwo
  },
  {
    path: '/pageone',
    name: '全国温度',
    component: PageOne
  },
  {
    path: '/map',
    component: MapView
  },
  {
    path: '/edit',
    component: Edit
  },

  {
    path: '/pagethree',
    name: '全国天气',
    component: PageThree
  },
  {
    path: '/add',
    component: Add
  }
]

const router = new VueRouter({
  routes
})

export default router
